  //////////////////////////////////////////////////////
//  Template Name: octAdmin
//  Author: octathemes
//  Email: octathemes@gmail.com
//  File: table-peity-example.js
///////////////////////////////////////////////////

$(function () {
  "use strict";
  
  // Basic Tables Peity chart
  $(".peity-line").peity("line");

});