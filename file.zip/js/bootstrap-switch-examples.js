//////////////////////////////////////////////////////
//  Template Name: octAdmin
//  Author: octathemes
//  Email: octathemes@gmail.com
//  File: bootstrap-switch-examples.js
///////////////////////////////////////////////////

$(function () {
    "use strict";
//bootstrap switch
$("[name='my-checkbox']").bootstrapSwitch();

});